import { Component } from '@angular/core';

@Component({
  selector: 'app-segundo-component',
  templateUrl: './segundo-component.component.html',
  styleUrl: './segundo-component.component.css'
})

export class SegundoComponentComponent {
  textoDigitado: string = '';

  atualizarTexto(event: Event) {
    this.textoDigitado = (event.target as HTMLInputElement).value;
  }
}
