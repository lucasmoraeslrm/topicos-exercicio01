import { Component } from '@angular/core';

@Component({
  selector: 'app-primeiro-component',
  templateUrl: './primeiro-component.component.html',
  styleUrl: './primeiro-component.component.css'
})
export class PrimeiroComponentComponent {

  texto: string = '';
  textoExibido: string = '';

  exibirTexto() {
    this.textoExibido = this.texto;
  }

  corVermelha: boolean = false;

  mudarCor() {
    this.corVermelha = !this.corVermelha;
  }

}
